﻿
insert into logindata(name, address, password, username, confirmpassword,
mobile,NID,gender,dateofbirth,approval,status) values(
'nm','ad','user1','user1','user1','123','222',1,'22-10-18',0,0)